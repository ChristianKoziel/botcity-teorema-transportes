#!/bin/bash

zip -r "automacaoTransporte.zip" * -x "automacaoTransporte.zip"